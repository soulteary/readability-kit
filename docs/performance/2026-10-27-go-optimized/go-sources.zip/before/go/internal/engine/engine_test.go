// SPDX-License-Identifier: Apache-2.0
package engine

import (
	"context"
	"github.com/soulteary/readability-kit/go/internal/dom"
	"github.com/soulteary/readability-kit/go/internal/html"
	"math"
	"strings"
	"testing"
)

func parseTest(t *testing.T, markup string) *html.Node {
	t.Helper()
	doc, err := html.Parse(strings.NewReader(markup))
	if err != nil {
		t.Fatal(err)
	}
	return doc
}

func TestFragmentLinkDensity(t *testing.T) {
	for _, tc := range []struct {
		href string
		want float64
	}{{"#", 1}, {"#section", .3}, {"/other", 1}} {
		t.Run(tc.href, func(t *testing.T) {
			doc := parseTest(t, `<div><a href="`+tc.href+`">abcde</a></div>`)
			got := density(dom.Find(doc, "div"))
			if math.Abs(got-tc.want) > 1e-9 {
				t.Fatalf("link density=%g want %g", got, tc.want)
			}
		})
	}
}

func TestTitleHeaderPunctuation(t *testing.T) {
	title := "Evolve: Shared Mutable History"
	if got := similarity(title, title+"¶"); got != 1 {
		t.Fatalf("title with permalink punctuation similarity=%g", got)
	}
	doc := parseTest(t, `<article><h1>Evolve: Shared Mutable History<a href="#title">¶</a></h1><p>A substantive paragraph explains the article in sufficient detail for extraction.</p></article>`)
	out, err := Extract(context.Background(), doc, Options{Title: title, CharThreshold: 1})
	if err != nil {
		t.Fatal(err)
	}
	if strings.Contains(dom.Text(out), "¶") {
		t.Fatal("duplicate title with permalink remained")
	}
}

func TestBrReplacementBeforeFontConversion(t *testing.T) {
	doc := parseTest(t, `<div>before<br><br><font color="red">after</font></div>`)
	prepDocument(doc)
	div := dom.Find(doc, "div")
	children := elementChildren(div)
	if len(children) != 2 || children[0].Data != "p" || children[0].FirstChild != nil || children[1].Data != "span" {
		t.Fatalf("br replacement consumed font content before conversion: %s", dom.Inner(div))
	}
}

func TestHiddenVisibility(t *testing.T) {
	doc := parseTest(t, `<article><div style="visibility: hidden;"><p>Hidden paragraph contains sufficient words to otherwise qualify as the article body.</p></div><p>Visible paragraph has sufficient words and punctuation for reliable article selection.</p></article>`)
	out, err := Extract(context.Background(), doc, Options{CharThreshold: 1})
	if err != nil {
		t.Fatal(err)
	}
	if out == nil || strings.Contains(dom.Text(out), "Hidden paragraph") || !strings.Contains(dom.Text(out), "Visible paragraph") {
		t.Fatalf("unexpected visible article: %v", out)
	}
}
