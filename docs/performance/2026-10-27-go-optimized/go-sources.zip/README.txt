Go module source snapshots before and after the optimization. before matches Go source hashes in performance/2026-10-27-rust-parity/manifest.json; after matches this experiment manifest.json.
Build each snapshot as go/ in a copy of this repository so benchmark fixture relative paths resolve. Repository JavaScript, Rust, shared corpus, driver and locked dependencies are unchanged.
Measured builds: Go 1.27.1 darwin/arm64, CGO_ENABLED=0, go build -trimpath -o ../go-dist/ ./cmd/readability-kit ./cmd/readability-kit-bench ./cmd/readability-kit-compat
