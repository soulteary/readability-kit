Measured evidence: raw samples, worker/CLI stdout, stderr, exact process commands, input manifest and source/build hashes.
Input payload JSON files are excluded: rebuild from the original repository fixtures with scripts/benchmark-all.mjs and the recorded seed/config. The repository source is required to reproduce the binaries; git HEAD alone is insufficient when the recorded workspace contains uncommitted changes.
Summarize offline: node scripts/summarize-benchmark.mjs raw.json summary.json

Additional Go allocation diagnostics and report display augmentation are included. Allocation traffic is not peak RSS. Source snapshots and complete auxiliary harness outputs are in the separate go-sources.zip. Display augmentation runs after measurement and does not modify extraction or timing.
Rebuild HTML: node scripts/render-benchmark.mjs summary.json report.html - rust-compatibility.json; node augment-memory.mjs report.html allocations.json summary.json previous-summary.json
