package memorybench
import (
 "context"
 "encoding/json"
 "os"
 "path/filepath"
 "testing"
 readability "github.com/soulteary/readability-kit/go"
)
var sink []byte
func BenchmarkArticle(b *testing.B) {
 for _, name := range []string{"rtl-4", "ehow-2", "schema-org-context-object"} {
  input, err := os.ReadFile(filepath.Join(os.Getenv("READABILITY_CORPUS_ROOT"), "vendor/mozilla/test/test-pages", name, "source.html"))
  if err != nil { b.Fatal(err) }; html := string(input)
  for _, engine := range []readability.Engine{readability.Chromium, readability.Mozilla} {
   b.Run(name+"/"+string(engine), func(b *testing.B) {
    opts:=readability.ExtractOptions{URL:"https://example.com/test/page.html",Engine:engine}
    run:=func() { a,e:=readability.ExtractHTML(context.Background(),html,opts); if e!=nil || a==nil { b.Fatalf("article: %v",e) }; sink,e=json.Marshal(a); if e!=nil { b.Fatal(e) } }
    for i:=0;i<2;i++ { run() }; b.ReportAllocs(); b.ResetTimer()
    for i:=0;i<b.N;i++ { run() }
   })
  }
 }
}
