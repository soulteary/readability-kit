package main
import("encoding/json";"fmt";"os"; readability "github.com/soulteary/readability-kit/go")
func main(){ var req struct{ Cases []struct{ID string `json:"id"`; HTML string `json:"html"`; Options json.RawMessage `json:"options"`} `json:"cases"` };if e:=readability.DecodeJSONRequest(os.Stdin,&req);e!=nil {panic(e)};size:=0;for _,c:=range req.Cases{size+=len(c.HTML)};fmt.Printf("{\"cases\":%d,\"bytes\":%d}\n",len(req.Cases),size) }
