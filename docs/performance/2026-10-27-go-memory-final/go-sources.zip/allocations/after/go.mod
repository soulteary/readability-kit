module readability-memory-bench

go 1.25.0

require github.com/soulteary/readability-kit/go v0.0.0

require golang.org/x/net v0.55.0 // indirect

replace github.com/soulteary/readability-kit/go => /Users/soulteary/Lab/github/readability-kit/go
