Post-review four-language measurements and interleaved three-version controls.
Current measured files are stored under sources/ and match manifest.json.
The unoptimized wheel is under before/. The exact optimized/pre-review runtime,
worker and input loader were recovered from an archived source/binary snapshot;
they are under optimized-reference/ with per-file hashes and archive provenance.
Recreate an isolated Python environment with that package directory on sys.path.
Input payloads can be reconstructed from the locked corpus and sampling code.
Absolute executable paths in process specs record this host; they are not portable.
