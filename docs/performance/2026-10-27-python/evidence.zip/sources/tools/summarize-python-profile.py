#!/usr/bin/env python3
"""Aggregate diagnostic phases; no extraction or timing is performed here."""
import json
from pathlib import Path
import statistics
import sys

PHASES = ['pythonPrepareNs', 'nativeOptionsNs', 'nativeExtractNs', 'nativeSerializeNs',
          'boundaryResidualNs', 'pythonDecodeArticleNs', 'toDictNs', 'pythonJSONNs']


def stats(values):
    values = sorted(values)
    return {'n': len(values), 'meanNs': statistics.mean(values),
            'p50Ns': values[(len(values)-1)//2],
            'p95Ns': values[max(0, (95*len(values)+99)//100-1)],
            'minNs': values[0], 'maxNs': values[-1]}


def main():
    source, destination = map(Path, sys.argv[1:])
    raw = json.loads(source.read_text())
    result = {'schema': 1, 'nativeSha256': raw['nativeSha256'], 'engines': {},
              'method': 'Sum of per-page mean diagnostic phase durations, not public benchmark medians.'}
    for engine in ('chromium', 'mozilla'):
        result['engines'][engine] = {}
        for scope in ('full', 'detail'):
            jobs = [j for j in raw['jobs'] if j['engine'] == engine and j['scope'] == scope]
            assert len(jobs) == raw['replicates']
            samples = {}
            for job in jobs:
                for case in job['cases']:
                    for row in case['samples']:
                        assert sum(row[k] for k in PHASES) == row['totalNs']
                        assert all(row[k] >= 0 for k in PHASES)
                    samples.setdefault(case['id'], []).extend(case['samples'])
            expected = raw['replicates'] * (3 if scope == 'full' else 10)
            assert all(len(rows) == expected for rows in samples.values())
            cases = {name: {phase: stats([row[phase] for row in rows])
                            for phase in [*PHASES, 'totalNs']}
                     for name, rows in samples.items()}
            totals = {phase: sum(case[phase]['meanNs'] for case in cases.values())
                      for phase in [*PHASES, 'totalNs']}
            result['engines'][engine][scope] = {'cases': cases, 'sumPageMeansNs': totals}
    destination.write_text(json.dumps(result, indent=2)+'\n')


if __name__ == '__main__':
    main()
