// SPDX-License-Identifier: Apache-2.0
use pyo3::exceptions::{PyRuntimeError, PyValueError};
use pyo3::prelude::*;

// Own the inputs before detaching: no Python objects or shared DOM cross into
// extraction. JSON is limited to options and results; HTML travels separately.
#[pyfunction]
fn extract_json(py: Python<'_>, html: String, options: String) -> PyResult<String> {
    let value = serde_json::from_str(&options).map_err(|e| PyValueError::new_err(e.to_string()))?;
    let options = readability_core::boundary::decode_extract_options(&value, true)
        .map_err(PyValueError::new_err)?;
    let article = py
        .detach(move || readability_core::extract_html(&html, &options))
        .map_err(|e| PyRuntimeError::new_err(e.to_string()))?;
    serde_json::to_string(&article).map_err(|e| PyRuntimeError::new_err(e.to_string()))
}

#[pyfunction]
fn readerable(py: Python<'_>, html: String, options: String) -> PyResult<bool> {
    let value = serde_json::from_str(&options).map_err(|e| PyValueError::new_err(e.to_string()))?;
    let options =
        readability_core::boundary::readerable_options(&value).map_err(PyValueError::new_err)?;
    py.detach(move || readability_core::is_probably_readerable(&html, &options))
        .map_err(|e| PyRuntimeError::new_err(e.to_string()))
}

// Private test transport. Public Python API never exposes raw extraction.
#[pyfunction]
fn compatibility_request(py: Python<'_>, request: String) -> PyResult<String> {
    let response = py.detach(move || readability_core::boundary::process(&request));
    serde_json::to_string(&response).map_err(|e| PyRuntimeError::new_err(e.to_string()))
}

// Diagnostic-only entry: does not add clocks to the public extraction path.
// Timings exclude argument conversion before entry and return conversion.
#[pyfunction]
fn profile_extract_json(
    py: Python<'_>,
    html: String,
    options: String,
) -> PyResult<(String, u64, u64, u64)> {
    let start = std::time::Instant::now();
    let value = serde_json::from_str(&options).map_err(|e| PyValueError::new_err(e.to_string()))?;
    let options = readability_core::boundary::decode_extract_options(&value, true)
        .map_err(PyValueError::new_err)?;
    let decoded = start.elapsed().as_nanos() as u64;
    let start = std::time::Instant::now();
    let article = py
        .detach(move || readability_core::extract_html(&html, &options))
        .map_err(|e| PyRuntimeError::new_err(e.to_string()))?;
    let extracted = start.elapsed().as_nanos() as u64;
    let start = std::time::Instant::now();
    let output =
        serde_json::to_string(&article).map_err(|e| PyRuntimeError::new_err(e.to_string()))?;
    let serialized = start.elapsed().as_nanos() as u64;
    Ok((output, decoded, extracted, serialized))
}

#[pymodule]
fn _native(module: &Bound<'_, PyModule>) -> PyResult<()> {
    module.add_function(wrap_pyfunction!(extract_json, module)?)?;
    module.add_function(wrap_pyfunction!(profile_extract_json, module)?)?;
    module.add_function(wrap_pyfunction!(readerable, module)?)?;
    module.add_function(wrap_pyfunction!(compatibility_request, module)?)?;
    Ok(())
}
