"""Stable, typed result objects for readability-kit."""
from dataclasses import asdict, dataclass
from typing import Literal

Engine = Literal["chromium", "mozilla"]

_ALIASES = {"text_content": "textContent", "site_name": "siteName", "published_time": "publishedTime"}


@dataclass(frozen=True)
class Article:
    title: str
    content: str
    text_content: str
    length: int
    url: str
    engine: Engine
    byline: str | None
    dir: str | None
    lang: str | None
    excerpt: str | None
    site_name: str | None
    published_time: str | None

    def to_dict(self, *, camel_case: bool = False) -> dict[str, object]:
        """Return all fields, retaining None metadata (JSON null)."""
        fields = asdict(self)
        if camel_case:
            return {_ALIASES.get(key, key): value for key, value in fields.items()}
        return fields

    @classmethod
    def _from_native(cls, value: dict) -> "Article":
        aliases = {value: key for key, value in _ALIASES.items()}
        return cls(**{aliases.get(key, key): value for key, value in value.items()})
