Measured files are under sources/ and verified against manifest.json.
Later report/memory tooling is under postprocessing/. No generated input payloads
are included: rebuild them from the versioned HTML corpus, seed and configuration.
The source snapshot contains native binaries for the measured host, not a portable
build environment. Install pinned JS dependencies, Python and Rust crates before
rebuilding. JSON comparison reports preserve their original provenance.
