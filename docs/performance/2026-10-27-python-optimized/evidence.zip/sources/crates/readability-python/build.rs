// SPDX-License-Identifier: Apache-2.0
use std::path::Path;

fn main() {
    // Other workspace builds do not need Python distribution metadata.
    if std::env::var_os("CARGO_FEATURE_EXTENSION_MODULE").is_none() {
        return;
    }
    let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("../..");
    let directory = [
        root.join("python/src/readability_kit/_licenses"),
        root.join("src/readability_kit/_licenses"),
    ]
    .into_iter()
    .find(|path| path.join("DEPENDENCIES.json").is_file())
    .expect("Missing Python dependency notices: run tools/build-python-package.py first");
    for name in ["DEPENDENCIES.json", "LICENSE", "NOTICE", "SHA256SUMS"] {
        let file = directory.join(name);
        assert!(
            file.is_file(),
            "Missing Python distribution metadata: {name}"
        );
        println!("cargo:rerun-if-changed={}", file.display());
    }
}
