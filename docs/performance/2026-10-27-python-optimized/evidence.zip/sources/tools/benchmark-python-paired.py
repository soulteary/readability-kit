#!/usr/bin/env python3
"""Interleaved old API/old loader, new API/old loader, new API/new loader controls."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import random
import shutil
import statistics
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--before-python', type=Path, required=True)
    parser.add_argument('--before-worker', type=Path, required=True)
    parser.add_argument('--before-wheel', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    out = args.output.resolve()
    (out / 'paired-jobs').mkdir(parents=True, exist_ok=True)
    (out / 'before').mkdir(exist_ok=True)
    shutil.copyfile(args.before_worker, out / 'before/worker.py')
    shutil.copyfile(args.before_wheel, out / 'before' / args.before_wheel.name)
    spec = importlib.util.spec_from_file_location('measure', ROOT / 'tools/benchmark-process.py')
    measure = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(measure)
    corpus = [{'id': p.parent.name, 'html': p.read_text(encoding='utf-8')} for p in (ROOT / 'vendor/mozilla/test/test-pages').glob('*/source.html')]
    corpus.sort(key=lambda c: (len(c['html'].encode()), c['id']))
    details = [corpus[int((len(corpus)-1)*q)] for q in (.1, .5, .9)]
    modes = ['before', 'api-only', 'after']
    native_hashes = {}
    for name, python in [('before', args.before_python), ('after', Path(sys.executable))]:
        native = subprocess.check_output([str(python), '-c', 'from readability_kit import _native; print(_native.__file__)'], text=True).strip()
        native_hashes[name] = hashlib.sha256(Path(native).read_bytes()).hexdigest()
    jobs = []
    for rep in range(6):
        for engine in ('chromium', 'mozilla'):
            for scope, items, iterations in [('full', corpus, 3), ('detail', details, 10)]:
                ordered = list(items)
                random.Random(20261027+rep).shuffle(ordered)
                request = {'cases': [{**c, 'options': {'url': 'https://example.com/test/page.html', 'engine': engine}} for c in ordered],
                           'warmup': 2, 'iterations': iterations, 'serialize': True, 'allowEmpty': True}
                inp = out / f'paired-input-{rep}-{engine}-{scope}.json'
                inp.write_text(json.dumps(request, ensure_ascii=False, separators=(',', ':')))
                for mode in modes[rep % 3:] + modes[:rep % 3]:
                    name = f'{rep}-{engine}-{scope}-{mode}'
                    prefix = out / 'paired-jobs' / name
                    python = args.before_python if mode == 'before' else Path(sys.executable)
                    worker = args.before_worker if mode != 'after' else ROOT / 'tools/benchmark-python-worker.py'
                    specification = {'command': [str(python), str(worker)], 'cwd': str(ROOT), 'inputFile': str(inp),
                                     'stdoutFile': str(prefix)+'.stdout', 'stderrFile': str(prefix)+'.stderr', 'timeoutSeconds': 600}
                    Path(str(prefix)+'.spec.json').write_text(json.dumps(specification))
                    stats = measure.measure(specification)
                    if stats['exitCode'] or stats['timedOut']:
                        raise RuntimeError(Path(specification['stderrFile']).read_text())
                    result = json.loads(Path(specification['stdoutFile']).read_text())
                    jobs.append({'replicate': rep, 'engine': engine, 'scope': scope, 'mode': mode, 'stats': stats, 'worker': result})
                print(f'Paired controls {rep+1}/6 {engine}/{scope}', flush=True)
    raw = {'schema': 1, 'seed': 20261027, 'replicates': 6, 'nativeHashes': native_hashes, 'jobs': jobs}
    (out / 'paired-raw.json').write_text(json.dumps(raw))
    summary = {'schema': 1, 'replicates': 6, 'modes': modes, 'nativeHashes': native_hashes, 'engines': {}}
    for engine in ('chromium', 'mozilla'):
        summary['engines'][engine] = {}
        for scope in ('full', 'detail'):
            values = {}
            signatures = {}
            for mode in modes:
                group = [j for j in jobs if (j['engine'], j['scope'], j['mode']) == (engine, scope, mode)]
                assert len(group) == 6
                samples = {}
                for job in group:
                    for case in job['worker']['cases']:
                        samples.setdefault(case['id'], []).extend(case['durationsNs'])
                        signature = (case['lengths'][0], case['checksums'][0], case['statuses'][0])
                        assert all(v == signature[0] for v in case['lengths'])
                        assert all(v == signature[1] for v in case['checksums'])
                        assert all(v == signature[2] for v in case['statuses'])
                        assert case['id'] not in signatures or signatures[case['id']] == signature
                        signatures[case['id']] = signature
                # Same nearest-rank median as the four-language summarizer.
                medians = {name: sorted(v)[(len(v)-1)//2]/1e6 for name, v in samples.items()}
                values[mode] = {'sumPageMediansMs': sum(medians.values()), 'perPageMs': medians,
                                'rssMiB': statistics.median(j['stats']['maxRSSBytes']/1048576 for j in group),
                                'workerWallMs': statistics.median(j['stats']['wallNs']/1e6 for j in group)}
            summary['engines'][engine][scope] = values
    (out / 'paired-summary.json').write_text(json.dumps(summary, indent=2)+'\n')


if __name__ == '__main__':
    main()
