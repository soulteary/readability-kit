#!/usr/bin/env python3
"""Verify an installed wheel in isolation and rebuild a wheel from its sdist.

Invoke with the build environment's Python after `maturin build --release --sdist`.
No upload/publish operation is performed.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile
import venv
import zipfile

ROOT = Path(__file__).resolve().parent.parent


def run(*args, cwd=None):
    subprocess.run([str(arg) for arg in args], cwd=cwd, check=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dist', type=Path, default=ROOT / 'python/dist')
    args = parser.parse_args()
    wheels = sorted(args.dist.resolve().glob('*.whl'))
    sources = sorted(args.dist.resolve().glob('*.tar.gz'))
    if len(wheels) != 1 or len(sources) != 1:
        raise SystemExit('Expected exactly one wheel and one sdist in --dist')
    with zipfile.ZipFile(wheels[0]) as archive:
        names = archive.namelist()
        assert not any('__pycache__' in name or name.endswith('.pyc') for name in names)
        prefix = 'readability_kit/_licenses/'
        for line in archive.read(prefix + 'SHA256SUMS').decode().splitlines():
            digest, name = line.split('  ', 1)
            assert hashlib.sha256(archive.read(prefix + name)).hexdigest() == digest, name
        metadata = json.loads(archive.read(prefix + 'DEPENDENCIES.json'))
        assert any(package['name'] == 'pyo3' for package in metadata['packages'])
        for suffix in ('py.typed', '_licenses/NOTICE', '_licenses/DEPENDENCIES.json'):
            assert any(name.endswith(suffix) for name in names), suffix
        assert any('/_licenses/source/' in name and name.endswith('.rs') for name in names)
    with tempfile.TemporaryDirectory(prefix='readability-python-') as temporary:
        temporary = Path(temporary)
        environment = temporary / 'venv'
        venv.EnvBuilder(with_pip=True).create(environment)
        python = environment / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
        run(python, '-m', 'pip', 'install', '--no-index', '--no-deps', wheels[0], cwd=temporary)
        run(python, '-m', 'unittest', 'discover', '-s', ROOT / 'python/tests', '-v', cwd=temporary)
        run(python, '-m', 'readability_kit', '--version', cwd=temporary)
        executable = environment / ('Scripts/readability-kit.exe' if os.name == 'nt' else 'bin/readability-kit')
        run(executable, '--version', cwd=temporary)
        source_root = temporary / 'source'
        with tarfile.open(sources[0]) as archive:
            archive.extractall(source_root, filter='data')
        project_files = list(source_root.rglob('pyproject.toml'))
        assert len(project_files) == 1, project_files
        project = project_files[0].parent
        run(sys.executable, '-m', 'maturin', 'build', '--release', '--locked',
            '--out', temporary / 'rebuilt', cwd=project)
        rebuilt = list((temporary / 'rebuilt').glob('*.whl'))
        assert len(rebuilt) == 1
        run(python, '-m', 'pip', 'install', '--no-index', '--no-deps', '--force-reinstall', rebuilt[0], cwd=temporary)
        run(python, '-m', 'unittest', 'discover', '-s', ROOT / 'python/tests', '-v', cwd=temporary)
    print('Wheel install, CLI, notices, isolated sdist rebuild and rebuilt wheel tests passed.')


if __name__ == '__main__':
    main()
