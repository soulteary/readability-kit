Four-language samples and three-mode interleaved Python controls.
All measured files match manifest.json. Source/build snapshots are under sources/.
The old Python wheel and worker are under before/. Recreate its venv locally;
absolute machine-specific executable paths are provenance, not portable commands.
Input JSON files are reconstructible from the corpus, seed and measurement code.
Report adapters created after sampling are under postprocessing/.
