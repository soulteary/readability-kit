Measured evidence: raw samples, worker/CLI stdout, stderr, exact process commands, input manifest and source/build hashes.
Input payload JSON files are excluded: rebuild from the original repository fixtures with scripts/benchmark-all.mjs and the recorded seed/config. The repository source is required to reproduce the binaries; git HEAD alone is insufficient when the recorded workspace contains uncommitted changes.
Summarize offline: node scripts/summarize-benchmark.mjs raw.json summary.json
